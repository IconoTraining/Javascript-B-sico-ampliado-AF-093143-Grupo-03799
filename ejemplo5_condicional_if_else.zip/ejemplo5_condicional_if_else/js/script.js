var estiloBorde = false;   // false -> no tiene borde,  true -> si tiene borde
var estiloColor = false;
var estiloSombra = false;

function borde(){
    if (!estiloBorde){
        // pongo el borde
        document.getElementById("cuadrado").style.border = "5px solid blue";
        estiloBorde = true;
    } else {
        // quito el borde
        document.getElementById("cuadrado").style.border = "none";
        estiloBorde = false;
    }
}

function color(){
    if (!estiloColor){
        document.getElementById("cuadrado").style.backgroundColor = "pink";
    } else {
        document.getElementById("cuadrado").style.backgroundColor = "darkgrey";
    }
    estiloColor = !estiloColor;
}

function sombra(){
    if (!estiloSombra){
        document.getElementById("cuadrado").className = "sombra";
    } else {
        document.getElementById("cuadrado").className = "none";
    }
    estiloSombra = !estiloSombra;
}