// Declaracion explicita
var nombre = "Anabel";

// Declaracion implicita
apellido = "Vegas";

// + -> operador de concatenacion
alert("Me llamo " + nombre + " y mi apellido es " + apellido);