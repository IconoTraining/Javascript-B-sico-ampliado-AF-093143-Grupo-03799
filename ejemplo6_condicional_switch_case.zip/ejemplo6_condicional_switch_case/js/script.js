function cambiarColor(){

    // event.target.id -> devuelve el id del elemento que ha provocado el evento
    switch(event.target.id){
        case "btn1":
            document.getElementById("btn1").className = "rojo";
            break;

        case "btn2":
            document.getElementById(event.target.id).className = "verde";
            break;

        case "btn3":
            document.getElementById(event.target.id).className = "azul";
            break;
    }
}