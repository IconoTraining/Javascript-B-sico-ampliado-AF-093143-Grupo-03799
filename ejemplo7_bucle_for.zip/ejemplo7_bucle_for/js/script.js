function cargarProvincias(){
    // Crear un array con el nombre de las provincias
    var arrayProvincias = new Array("Madrid","Valencia","Sevilla","Toledo");

    // Buscar el select de provincias
    var listaProvincias = document.getElementById("provincias");

    // Recorrer el array y generar un option por cada provincia,
    // luego agregarlo a la lista de provincias
    for(var i in arrayProvincias){
        listaProvincias.innerHTML += "<option value=" + i + ">" +
           arrayProvincias[i] + "</option>";
    }
}

function cargarPoblaciones(){
    var seleccionado = document.getElementById("provincias").selectedIndex;

    var arrayPoblaciones = null;

    switch(seleccionado){
        case 1:
            arrayPoblaciones = ["Getafe","Parla","Torrelodones"];
            break;
        case 2:
            arrayPoblaciones = ["Gandia","Cullera","Oliva"];
            break;
        case 3:
            arrayPoblaciones = ["Dos Hermanas","Espartinas","Los Palacios"];
            break;
        case 4:
            arrayPoblaciones = ["Talavera","Trillo","Cebolla"];
            break;
    }

    // Buscar el select de poblaciones
    var listaPoblaciones = document.getElementById("poblaciones");

    // limpiar las opciones anteriores
    listaPoblaciones.innerHTML = "<option>-- selecciona --</option>";

    for(var i in arrayPoblaciones){
        listaPoblaciones.innerHTML += "<option value=" + i + ">" +
        arrayPoblaciones[i] + "</option>";
    }

}