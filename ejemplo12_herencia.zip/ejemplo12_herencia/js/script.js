class Figura{

    constructor(x,y){
        this.x = x;
        this.y = y;
    }

    area(){
        return 0;
    }

    posicion(){
        // [x,y]
        return "[" + this.x + "," + this.y + "]";
    }

    mostrarDatos(){
        return "x: " + this.x + " y: " + this.y;
    }
}

class Circulo extends Figura{

    constructor(x, y, radio){
        super(x,y);   // Invocar al constructor de la superclase
        this.radio = radio;
    }

    area(){
        return Math.PI * Math.pow(this.radio, 2);
    }

    mostrarDatos(){
        return super.mostrarDatos() + " radio: " + this.radio;
    }
}

class Rectangulo extends Figura{

    constructor(x, y, base, altura){
        super(x, y);
        this.base = base;
        this.altura = altura;
    }

    area(){
        return this.base * this.altura;
    }

    mostrarDatos(){
        return super.mostrarDatos() + " base: " + this.base +
             " altura: " + this.altura;
    }
}