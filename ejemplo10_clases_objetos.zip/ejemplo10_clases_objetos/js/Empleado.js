class Empleado{

    // Se invoca para crear objetos (new)
    constructor(nombre, sexo, sueldo){
        this.nombre = nombre;
        this.sexo = sexo;
        this.sueldo = sueldo;
    }

    // Metodos
    mostrarInfo(){
        return "Nombre: " + this.nombre + " Sexo: " + this.sexo + 
            " Sueldo: " + this.sueldo;
    }
}


// new Empleado("Juan", "H", 35000);